<?php

class login
{
    private $error ="";
   
    public function login_check($data)
    {
        $userid = addslashes($data['userid']);
        $password = addslashes($data['password']);
        $username = addslashes($data['username']);   

        $query = "select * from tbluser where userid = $userid limit 1";
           
        $DB = new database();
        $result = $DB -> read($query);
            
        if($result)
        {
            $row = $result[0];
            if($password == $row['password'])
            {
               
                $_SESSION['userid'] = $row['userid'];
               
            }
            else
            {
                $this->error .= "wrong password<br>";
            }


            if($username == $row['username'])
            {
                $_SESSION['username'] = $row['username'];
            }
            else
            {
                $this->error .= "email not found<br>";
            }

        }
        else
        {
            $this->error .= "no such student number was found ";
        }
        
      
        

        return $this->error;
    }    
    

   
}

?>