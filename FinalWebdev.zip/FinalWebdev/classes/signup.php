<?php

    class Signup
    {
       private $error ="";
       
       public function evaluate($data)
       {
           foreach($data as $Key => $value)
           {
             #code....
             if(empty($value))
             {
                $this->error = $this->error. $Key . " is empty!<br> " ;
             }
             
             if($Key == "username")
             {
                if(!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$value))
                {
                    $this->error = $this->error.  " invalid email address!<br> " ;
                }
                
             }


             if($Key == "student_name"  )
             {
                 if(is_numeric($value))
                 {
                     $this->error = $this->error . " name can not be a number<br>";

                 }

                 if(strstr($value," "))
                 {
                    $this->error = $this->error . " name can not have spacesr<br>";   
                 }

             }

             if($Key == "studnet_surname")
             {
                 if(is_numeric($value))
                 {
                     $this->error = $this->error . "surname name can not be a number<br>";

                 }

                 if(strstr($value," "))
                 {
                    $this->error = $this->error . "  can not have spacesr<br>";   
                 }

             }


           }

           if($this->error == "")
           {
                $this->create_user($data);
           }
           else
           {
               return $this->error;

           }
       }

       public function create_user($data)
       {
            $student_name = $data['student_name'];
            $student_surname = $data['student_surname'];
            $username = $data['username'];
            $password = $data['password'];
           
            $userid = $data['userid'];

            //$userid = $this->create_userid();

            $query = "insert into tbluser(userid,student_name,student_surname,username,password) 
            values( '$userid', '$student_name','$student_surname','$username','$password')";

          

            $DB = new database();
            $DB -> save($query);
            
       }
            

       //private function create_userid()
       //{
           // $length = rand(4,10);
           // $number ="";
           //for ($i = 0 ; $i < $length;$i++ )
           //{
                #code......
               // $new_rand = rand(0,9);
               //$number = $number . $new_rand;

            //}

           //return $number;
        //}    
    }

?>