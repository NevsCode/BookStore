<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="images/logo.png">
    <link rel="stylesheet" href="style.css ?v=<?php echo time();?>">
    <link rel="stylesheet" href="styleOne.css ?v=<?php echo time();?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.3/font/bootstrap-icons.css">
    <title>SecondHandBookStore</title>
</head>
<body>
<div class="top-container">
        <!-- log image-->
        <div class="logo">
           <a href="index.php"><img src="images/logo.png"></a>
            
        </div>

        <!--seaching place -->
        <div class="search-bar">
            <h6>second hand Book store </h6>
            <form action="">
                <input type="text" placeholder="Search books" name="search">
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
            
        </div>

        
        <!-- login page-->
        <div class="top-bar--right-menu">
           <a href="login.php"  < i class="bi bi-person-circle" > </i> Login  </a> 
               
           
        </div>
        
        

        <!---the shopping cart -->
        <div class="cart">
            <i class="bi bi-cart4"></i>
            <div id="cart_Amount">0</div>
        </div>
        

    </div>

    
    <div class="bottom_container">
        <!-- mune bars -->
        <div class="menu_bars">
            <nav>
                <ul>
                   <li>
                       <a href="index.php">Home</a>
                   </li>
                   <li>
                       <a href="ourbooks.php">Our Books</a>
                   </li>
                   <li>
                       <a href="contactus.php">Contact Us</a>
                   </li>
                   <li>
                       <a href="onsale.php">On Sale</a>
                   </li>
                   
                </ul>
            </nav>
               
        </div>

    </div>

    <!--aboout our books -->
    <div class="about_book">
        <h5>Our Books</h5>

        <h1>Cover Images</h1>

        <p>Sometimes cover images may not be accurate.Please contact rosebank college if you're looking for a specific cover.</p>
        <h1>Out of Stock Books</h1>
        <p>We sell on various platforms and it can (and does) happen that a book you order is out of stock. In such instances we try to source the book but if we're unable to,we'll let you know.</p>
        <h1>Book Descriptions</h1>
        <p>We try to provide accurate information about each book but mistakes can creep in. Please read the book details under the Additional Information tab if you are looking for a specific edition of a book.</p>
        <h1>Couries</h1>
        <p>Sometimes we'll send a parcel with a different courier than the one you selected. This will be for our cost. If you feel strongly about using a specific courier, please add that in <br>the Comments section during Checkout.</p>
    </div>

    <br>
    <br>

    <?php

      include "footer.html";
    ?>


</body>
</html>