<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="images/logo.png">
    <link rel="stylesheet" href="style.css ?v=<?php echo time();?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.3/font/bootstrap-icons.css">
    <title>SecondHandBookStore</title>
</head>
<body>
<div class="top-container">
        <!-- log image-->
        <div class="logo">
           <a href="index.php"><img src="images/logo.png"></a>
            
        </div>

        <!--seaching place -->
        <div class="search-bar">
            <h6>second hand Book store </h6>
            <form action="">
                <input type="text" placeholder="Search books" name="search">
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
            
        </div>

        
        <!-- login page-->
        <div class="top-bar--right-menu">
           <a href="login.php"  < i class="bi bi-person-circle" > </i> Login  </a> 
         
        </div>
        
        <!---the shopping cart -->
        <div class="cart">
            <i class="bi bi-cart4"></i>
            <div id="cart_Amount">0</div>
        </div>
        
    </div>

    
    <div class="bottom_container">
        <!-- mune bars -->
        <div class="menu_bars">
            <nav>
                <ul>
                   <li>
                       <a href="index.php">Home</a>
                   </li>
                   <li>
                       <a href="ourbooks.php">Our Books</a>
                   </li>
                   <li>
                       <a href="contactus.php">Contact Us</a>
                   </li>
                   <li>
                       <a href="onsale.php">On Sale</a>
                   </li>
                   
                </ul>
            </nav>
               
        </div>

    </div>

    <section class="contact_form">
        <div class="contact-heading">
            <h1>Contact Us</h1>
        </div>
        <form  action="userinform.php" method="post">
            <label for="Name">Name</label>
            <input type="text" name="user" placeholder="Your full name" require>
            <label for="Email">Email</label>
            <input type="email" name="email" placeholder="Your E-mail" require><br/>
            <label for="Message">Message</label>
            <textarea name="message" placeholder="Type your message here......"></textarea><br/>
            <button type="submit">Submit</button>
        </form>
    </section>

    <br>
    <br>
    <?php

      include "footer.html";
    ?>
</body>
</html>