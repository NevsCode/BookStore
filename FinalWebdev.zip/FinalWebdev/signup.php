<?php

    
    include("classes/DBconn.php");
    include("classes/signup.php");

    $student_name ="";
    $student_surname ="";
    $username ="";
    $userid ="";

    if($_SERVER['REQUEST_METHOD'] == 'POST')
    {
        $Signup = new signup();
        $result = $Signup -> evaluate($_POST);


        if($result != "")
        {
            echo "<div style= 'text-align:center;font-size:12px;color:red;backgrond-color:black'>";
            echo "the following erros occured:<br> <br>";
            echo $result;
            echo "</div>";

        }else
        {
            header("Location: login.php");
            die;
        }

        
        $student_name = $_POST['student_name'];
        $student_surname =  $_POST['student_surname'];
        $username =  $_POST['username'];
        $userid = $_POST['userid'];
    }

    
    
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="images/logo.png">
    <link rel="stylesheet" href="style.css ?v=<?php echo time();?>">
    
    <link rel="stylesheet" href="styleOne.css ?v=<?php echo time();?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.3/font/bootstrap-icons.css">
    <title>SecondHandBookStore</title>
</head>
<body>
<div class="top-container">
        <!-- log image-->
        <div class="logo">
           <a href="index.php"><img src="images/logo.png"></a>
            
        </div>

        <!--seaching place -->
        <div class="search-bar">
            <h6>second hand Book store </h6>
            <form action="">
                <input type="text" placeholder="Search books" name="search">
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
            
        </div>

        
        <!-- login page-->
        <div class="top-bar--right-menu">
            <i class="bi bi-person-circle">
                <a href="login.php "title="My Account ">Login</a>
                <div id="cart_Amount">0</div>
            </i>
        </div>
        

        <!---the shopping cart -->
        <div class="cart">
            <i class="bi bi-cart4"></i>
            <div id="cart_Amount">0</div>
        </div>
        

    </div>

    
    <div class="bottom_container">
        <!-- mune bars -->
        <div class="menu_bars">
            <nav>
                <ul>
                   <li>
                       <a href="index.php">Home</a>
                   </li>
                   <li>
                       <a href="ourbooks.php">Our Books</a>
                   </li>
                   <li>
                       <a href="contactus.php">Contact Us</a>
                   </li>
                   <li>
                       <a href="onsale.php">On Sale</a>
                   </li>
                   
                </ul>
            </nav>
               
        </div>

    </div>

    <form method= "post" action="">
        <div class="signup_page">
        <h2>Student signup</h2>
        <hr>
        
        <input value="<?php echo $student_name ?>" name="student_name" type="text" id="text" placeholder="Student Name"><br><br>
        <input value="<?php echo $student_surname ?>" name="student_surname" type="text" id="text" placeholder="Student Surname"><br><br>
        <input value="<?php echo $username ?>" name="username" type="text" id="text" placeholder="Your email"><br><br>
        <input value="<?php echo $userid ?>" name="userid" type="text" id="text" placeholder="Student number "><br><br>
        <input name="password" type="password" id="text" placeholder="Your Password"><br><br>
        <input name="password2" type="password" id="text" placeholder="Retype Password"><br><br>
        <input type="submit" id="button" value="Sign up">
    
        <nav>
            <div class="singUp-bar--right-menu">
            <ul >
               
                <li class="login_space">
                <a href="login.php" class="
                        top-bar__login-link
                        icon-user
                    " title="My Account ">
                    Login</a>
                </li>

            </ul>
            </div>
        </nav>
        </div>
     </form>
     
        <br>
        <br>

        <?php

            include "footer.html";
        ?>  

</body>
</html>