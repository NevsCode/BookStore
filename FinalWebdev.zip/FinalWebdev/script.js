//document.getElementById("cart_Amount").innerText = 5

let book = 0;
function purchase()
{
    book += 1;
    document.getElementById("cart_Amount").textContent = book
}

let savebook = document.getElementById("cart_Amount")
function cart()
{
    
    savebook.textContent += cart_Amount
    cart_Amount.textContent = 0
    book = 0
}

const data = [
    {
        id : 0,
        img : 'images/images1',
        name: 'constitutional law in context',
        price:550,
        save:100,
        delivery:'in between 5 days of work',
        intemInart : false
    
    },

    {
        id : 1,
        img :'images/images2',
        name:'Animal physiology' ,
        price:750,
        save:150,
        delivery:'in between 5 days of work',
        intemInart : false
    
    },

    {
        id :2 ,
        img : 'images/images3',
        name:'economic',
        price:600,
        save:200,
        delivery:'in between 5 days of work',
        intemInart : false
    
    },

    {
        id : 3,
        img : 'images/images4',
        name:'businnes management',
        price:550,
        save:100,
        delivery:'in between 5 days of work',
        intemInart : false
    
    },

    {
        id : 4,
        img : 'images/images4',
        name:'Econimics',
        price:600,
        save:150,
        delivery:'in between 5 days of work',
        intemInart : false
    
    },

    {
        id :5 ,
        img : 'images/images5',
        name:'programming logic & design',
        price:900,
        save:250,
        delivery:'in between 5 days of work',
        intemInart : false
    
    },

    {
        id :6 ,
        img : 'images/images6',
        name:'Java programming',
        price:700,
        save:150,
        delivery:'in between 5 days of work',
        intemInart : false
    
    },

    {
        id :7 ,
        img : 'images/images7',
        name:'Managerial Finance',
        price:850,
        save:200,
        delivery:'in between 5 days of work',
        intemInart : false
    
    },

   
];

let cartlist = [];
var i;

var detail = document.getElementsByClassName('books');
var detailsname = document.getElementById('books_name'); 
var detailsprice = document.getElementById('books_price'); 
var yousave = document.getElementById('yousaved'); 
var back = document.getElementById('back'); 

back.addEventListener('click',displyCart);
var addToCarts = document.querySelectorAll('.add_button');

var cart = document.getElementById('cart');
var carts = document.getElementById('carts');

carts.addEventListener('click',() => addToCarts(getId));

var getId;
var home = document. getElementById('logo');
home.addEventListener('click',hideCart);

document.addEventListener('click',function(e)
{
    if(e.target.id == 'remove')
    {
        var itemId = e.target.parentNode.id;
        removeFromCart(itemId);
    }
})

addToCarts.forEach(val=>addEventListener('click'), )


 






