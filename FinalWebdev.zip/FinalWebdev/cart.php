<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="images/logo.png">
    <link rel="stylesheet" href="style.css ?v=<?php echo time();?>">
    <link rel="stylesheet" href="styleOne.css ?v=<?php echo time();?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.3/font/bootstrap-icons.css">
    <title>SecondHandBookStore</title>
</head>
<body>
<div class="top-container">
        <!-- log image-->
        <div class="logo">
           <a href="index.php"><img src="images/logo.png" id="logo"></a>
            
        </div>

        <!--seaching place -->
        <div class="search-bar">
            <h6>second hand Book store </h6>
            <form action="">
                <input type="text" placeholder="Search books" name="search">
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
            
        </div>

        
        <!-- login page-->
        <div class="top-bar--right-menu">
           <a href="login.php"  < i class="bi bi-person-circle" > </i> Login  </a> 
               
           
        </div>
        

        <!---the shopping cart -->
        <div class="cart">
            <a href="cart.php" onclick="cart()"> <i class="bi bi-cart4"></i> </a>
            <div id="cart_Amount">0</div>
        </div>
        

    </div>
    
    <div class="cart_page">
        <h3>Shopping Cart</h3>

        <div id="empty_cart">
            <h1>Your cart is Empty</h1>
        </div>

        <div id="cart_with_items">
            <div id="cart_column">
                <h3>Products</h3>
                <h3>Products name</h3>
                <h3>Total</h3>
                <h3>Quantity</h3>
                <h3>Remove</h3>
            </div>
            
        </div>

        <div id="item-body">

        </div>

        <div id="total">
            <h3 id="total-items">Quantity</h3>
            <h3 id="total-amount">Amount</h3>
            <h3 id="yousaved">Your Saved </h3>
        </div>

    </div>

    <?php

        include "footer.html";
    ?>  
    <script src="script.js ?v=<?php echo time();?>"></script> 
</body>
</html>