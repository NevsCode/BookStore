<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="images/logo.png">
    <link rel="stylesheet" href="style.css ?v=<?php echo time();?>">
    <link rel="stylesheet" href="styleOne.css ?v=<?php echo time();?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.3/font/bootstrap-icons.css">
    <title>SecondHandBookStore</title>
</head>
<body>
    <div class="top-container">
        <!-- log image-->
        <div class="logo">
           <a href="index.php"><img src="images/logo.png" id="logo"></a>
            
        </div>

        <!--seaching place -->
        <div class="search-bar">
            <h6>second hand Book store </h6>
            <form action="">
                <input type="text" placeholder="Search books" name="search">
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
            
        </div>

        
        <!-- login page-->
        <div class="top-bar--right-menu">
           <a href="login.php"  < i class="bi bi-person-circle" > </i> Login  </a> 
               
           
        </div>
        

        <!---the shopping cart -->
        <div class="cart">
            <a href="cart.php"> <i class="bi bi-cart4"></i> </a>
            <div id="cart_Amount">0</div>
        </div>
        

    </div>

    
    <div class="bottom_container">
        <!-- mune bars -->
        <div class="menu_bars">
            <nav>
                <ul>
                   <li>
                       <a href="index.php">Home</a>
                   </li>
                   <li>
                       <a href="ourbooks.php">Our Books</a>
                   </li>
                   <li>
                       <a href="contactus.php">Contact Us</a>
                   </li>
                   <li>
                       <a href="onsale.php">On Sale</a>
                   </li>
                   
                </ul>
            </nav>
               
        </div>

    </div>

    <div class="books_online" id="0">
        <div class="books">
            <a href="contactus.php" title="email if book available"><img width="150" src="images/images1.jpg"  alt="img" id="card-img"></a>
            <div class="details">
                <h3 id="books_price">Constitutional Law in context</h3>
            </div>
            <div class="price-quantity">
                <h2 id="books_price">R 550</h2>
                <hr>
                <div class="add_buttons">
                   
                    <div class="add_buttons">
                        <i class="bi bi-cart4" ></i>  
                        <button onclick="purchase()" >Addtocart</button>
                  
                    </div>
                   
                </div>
            </div>
        </div>

        <div class="books" id="1">
        <a href="contactus.php" title="email if book available"> <img width="150" src="images/images2.jpg"  alt="img" id="card-img"></a>
           
            <div class="details">
                <h3 id="books_name">Animal physiology</h3>
            </div>
            <div class="price-quantity">
                <h2 books_price>R 750</h2>
                <hr>
                <div class="add_buttons">
                   <i class="bi bi-cart4" ></i>  
                   <button onclick="purchase()" >Addtocart</button>
                  
                </div>
            </div>
        </div>

        <div class="books" id="2">
        <a href="contactus.php" title="email if book available"> <img width="150" src="images/images3.jpg"  alt="img" id="card-img"></a>
            
            <div class="details">
                <h3 id="books_name">Economics</h3>
            </div>
            <div class="price-quantity">
                <h2 id="books_price">R 600</h2>
                <hr>
                <div class="add_buttons">
                   
                    <div class="add_buttons">
                        <i class="bi bi-cart4" ></i>  
                        <button onclick="purchase()" >Addtocart</button>
                  
                    </div>
                   
                </div>
            </div>
        </div>

        <div class="books" id="3">
        <a href="contactus.php" title="email if book available"> <img width="150" src="images/imges4.jpg"  alt="img" id="card-img"></a>
            
            <div class="details">
                <h3 id="books_name">Business Management</h3>
            </div>
            <div class="price-quantity">
                <h2 id="books_price">R 550</h2>
                <hr>
                <div class="add_buttons">
                   
                    <div class="add_buttons">
                        <i class="bi bi-cart4" ></i> 
                        <button onclick="purchase()" >Addtocart</button>
                  
                    </div>
                   
                </div>
            </div>
        </div>

        <div class="books" id="4" >
            <a href="contactus.php" title="email if book available"><img width="150" src="images/images5.jpg" alt="img" id="card-img"></a>
            
            <div class="details">
                <h3 id="books_name">Economics</h3>
            </div>
            <div class="price-quantity">
                <h2 id="books_price">R 600</h2>
                <hr>
                <div class="add_buttons">
                   
                    <div class="add_buttons">
                        <i class="bi bi-cart4" ></i>  
                        <button onclick="purchase()" >Addtocart</button>
                  
                    </div>
                   
                </div>
            </div>
        </div>

        <div class="books" id="5">
        <a href="contactus.php" title="email if book available">  <img width="150" src="images/images6.jpg"  alt="img" id="card-img"></a>
           
            <div class="details">
                <h3 id="books_name">Programming logic & design</h3>
            </div>
            <div class="price-quantity">
                <h2 id="book_price">R 900</h2>
                <hr>
                <div class="add_buttons">
                    <div class="add_buttons">
                        <i class="bi bi-cart4" ></i>  
                        <button onclick="purchase()" >Addtocart</button>
                  
                    </div>
                    
                    
                </div>
            </div>
        </div>

        <div class="books" id="6">
            <a href="contactus.php" title="email if book available"><img width="150" src="images/images7.jpg"  alt="img" id="card-img"></a>
            
            <div class="details">
                <h3 id="books_name">Java programming</h3>
            </div>
            <div class="price-quantity">
                <h2 id="books_price">R 700</h2>
                <hr>
                <div class="add_buttons">
                   
                    <div class="add_buttons">
                        <i class="bi bi-cart4" ></i>  
                        <button onclick="purchase()" >Addtocart</button>
                  
                    </div>
                   
                </div>
            </div>
        </div>

        <div class="books" id="7">
            <a href="contactus.php" title="email if book available"><img width="150" src="images/images8.jpg"  alt="img" id="card-img"></a>
            
            <div class="details">
                <h3 id="book_name">Managerial Finance</h3>
            </div>
            <div class="price-quantity">
                <h2 id="books_price">R 850</h2>
                <hr>
                <div class="add_buttons">
                   
                    <div class="add_buttons">
                        <i class="bi bi-cart4" ></i> 
                        <button onclick="purchase()" >Addtocart</button>
                    </div>
                   
                </div>
            </div>
        </div>
        
    </div>


    <br>
    <br>

    <?php

        include "footer.html";
    ?>  
    <script src="script.js ?v=<?php echo time();?>"></script> 
</body>
</html>