<?php
session_start();
    
    include("classes/DBconn.php");
    include("classes/Login.php");

    $userid = "";
    $password ="";
    $username = "";

    if($_SERVER['REQUEST_METHOD'] == 'POST')
    {
      $login = new Login();
      $result = $login -> login_check($_POST);


      if($result != "")
      {
          echo "<div style= 'text-align:center;font-size:12px;color:white;backgrond-color:grey'>";
          echo "the following erros occured:<br> <br>";
          echo $result;
          echo "</div>";

      }else
      {
          header("Location: userAccount.php");
          die;
      }

        
        
        $userid =  $_POST['userid'];
        $password =  $_POST['password'];
        $username = $_POST['username'];
    
    }

    
    
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="images/logo.png">
    <link rel="stylesheet" href="style.css ?v=<?php echo time();?>">
    <link rel="stylesheet" href="styleOne.css ?v=<?php echo time();?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.3/font/bootstrap-icons.css">
    <title>SecondHandBookStore</title>
</head>
<body>
    <div class="top-container">
        <!-- log image-->
        <div class="logo">
           <a href="index.php"><img src="images/logo.png"></a>
            
        </div>

        <!--seaching place -->
        <div class="search-bar">
            <h6>second hand Book store </h6>
            <form action="">
                <input type="text" placeholder="Search books" name="search">
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
            
        </div>

        <!---login page-->
        <div class="top-bar--right-menu">
           <a href="login.php"  < i class="bi bi-person-circle" > </i> Login  </a> 
               
           
        </div>
        
        

        <!---the shopping cart -->
        <div class="cart">
            <i class="bi bi-cart4"></i>
            <div id="cart_Amount">0</div>
        </div>
        

    </div>

    
    <div class="bottom_container">
        <!-- mune bars -->
        <div class="menu_bars">
            <nav>
                <ul>
                   <li>
                       <a href="index.php">Home</a>
                   </li>
                   <li>
                       <a href="ourbooks.php">Our Books</a>
                   </li>
                   <li>
                       <a href="contactus.php">Contact Us</a>
                   </li>
                   <li>
                       <a href="onsale.php">On Sale</a>
                   </li>
                   
                </ul>
            </nav>
               
        </div>

    </div>

    <form method="post" action=""> 
          <div class="login_page">
          <h2>Student login</h2>
          <hr>
          <input value="<?php echo $username ?>" name="username" type="email" id="text" placeholder="Username"><br><br>
          <input name="userid" value="<?php echo $userid ?>" type="text" id="text" placeholder="Student Number"><br><br>
          <input name="password" value="<?php echo $password ?>" type="password" id="text" placeholder="Your Password"><br><br>
          <input type="submit" id="button" value="Log in">
          <span class="hr2"> <hr> <Span>
          <h1>New Student? </h1>

          <nav>
            <div class="singUp-bar--right-menu">
              <ul >
                <li>
                  <a href="Signup.php" class="
                        top-bar__login-link
                        icon-user
                      " title="New Account ">
                      Sign Up</a>
                </li>
              </ul>
            </div>
          </nav>
        </div>

      </form>

        <br>
        <br>

        <?php

            include "footer.html";
        ?>  

</body>
</html>